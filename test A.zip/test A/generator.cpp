#include <bits/stdc++.h>
#define int long long
using namespace std;

/* Author: Hoang Quoc Viet */

/** END OF TEMPLATE **/

    mt19937_64 rng(chrono::system_clock::now().time_since_epoch().count());
    // mt19937_64 rng(124124);

    int randnum(int l, int r) {
        vector<int> arr;
        for (int i = 0; i < 10; ++ i) {
            arr.push_back(l + rng() % (r - l + 1));
        }
        return arr[rng() % 10];
    }

double randDouble(double l, double r) {
    uniform_real_distribution<double> cc(l, r);
    return cc(rng);
}

pair<int, int> get_two(int l, int r, set<pair<int, int>>& s) {
    int u, v;
    do {
        u = randnum(l, r);
        v = randnum(l, r);
    } while (u == v || s.count({u, v}));
    s.insert({u, v});
    s.insert({v, u});
    return {u, v};
}

int get_one(int l, int r, set<int>& s) {
    int u;
    do {
        u = randnum(l, r);
    } while (s.count(u));
    s.insert(u);
    return u;
}

vector<int> randper(int n, int base = 1) {
    vector<int> per;
    for (int i = 0; i < n; ++ i) {
        per.push_back(i + base);
    }
    shuffle(per.begin(), per.end(), rng);
    return per;
}

vector<pair<int, int>> randtree(int n) {
    vector<int> per = randper(n);
    vector<pair<int, int>> tree;
    for (int i = 1; i < n; ++ i) if (i) {
        int u = per[i], v = per[randnum(0, i - 1)];
        if (randnum(0, 1)) tree.push_back({u, v});
        else tree.push_back({v, u});
    }
    shuffle(tree.begin(), tree.end(), rng);
    return tree;
}

vector<pair<int, int>> randgraph(int n, int m, bool multigraph = 0) {
    vector<pair<int, int>> graph;
    set<pair<int, int>> s;
    if (!multigraph) {
        assert(m >= n - 1 && m <= n * (n - 1) / 2);
        graph = randtree(n);
        for (auto [u, v] : graph) {
            s.insert({u, v});
            s.insert({v, u});
        }
        m -= (n - 1);
    }
    while (m --) {
        auto [u, v] = get_two(1, n, s);
        if (randnum(0, 1)) graph.push_back({u, v});
        else graph.push_back({v, u});
    }
    return graph;
}

vector<int> distinct(int n, int l, int r) {
    assert(r - l + 1 >= n);
    set<int> s;
    vector<int> res;
    for (int i = 0; i < n; ++ i) {
        res.push_back(get_one(l, r, s));
    }
    return res;
}

vector<int> partition(int n, int sum, int min_value = 1) {
    assert(min_value * n <= sum);
    sum -= min_value * n;
    vector<int> pref_sum;
    pref_sum.push_back(sum);
    for (int i = 0; i + 1 < n; ++ i) {
        pref_sum.push_back(randnum(0, sum));
    }
    sort(pref_sum.begin(), pref_sum.end());
    vector<int> res;
    res.push_back(pref_sum[0]);
    for (int i = 1; i < n; ++ i) {
        res.push_back(pref_sum[i] - pref_sum[i - 1]);
    }
    for (auto& x : res) x += min_value;
    return res;
}

string randstr(int n, char fr = 'a', char to = 'z') {
    string str;
    for (int i = 0; i < n; ++ i) {
        str += randnum(fr, to);
    }
    shuffle(str.begin(), str.end(), rng);
    return str;
}

string randstr(int n, vector<char> list_of_char) {
    assert(list_of_char.size());
    string str;
    for (int i = 0; i < n; ++ i) {
        int u = randnum(0, list_of_char.size() - 1);
        str += list_of_char[u];
    }
    shuffle(str.begin(), str.end(), rng);
    return str;
}

const int test_case = 5;

void gen_test() {
    int n = randnum(2, 1e5);
    cout << n << endl;
    for (int i = 1; i <= n; ++ i) {
        cout << randnum(1, 200) << " \n"[i == n];
    }
}

main() {
    // freopen("input.txt", "w", stdout);

    if (test_case > 1) {
        cout << test_case << "\n\n";
    }

    for (int i = 1; i <= test_case; ++ i) {
        gen_test();
        cout << "\n";
    }

    return 0;
}

/*** VOI VOI VOI important things must be said three times :> ***/
