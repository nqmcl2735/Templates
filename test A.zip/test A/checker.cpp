#include <bits/stdc++.h>
using namespace std;
using ll = long long;

const int N = 2e5 + 5;

ifstream input("input.txt");
ifstream check("main_correct.txt");
ifstream ac("brute_force.txt");

int n, d12, d23, d31;
vector<int> adj[N];

void dfs(int u, int v, int dist, int par) {
    if (u == v && v == 3 && dist != d31) {
        cout << "WA31\n";
        cout << "expected " << d31 << "\n" << "found " << dist << "\n";
        exit(1);
    }
    if (u == v && v == 2 && dist != d23) {
        cout << "WA23\n";
        cout << "expected " << d23 << "\n" << "found " << dist << "\n";
        exit(1);
    }
    if (u == v && v == 1 && dist != d12) {
        cout << "WA12\n";
        cout << "expected " << d31 << "\n" << "found " << dist << "\n";
        exit(1);
    }
    for (auto c : adj[u]) {
        if (c == par) continue;
        dfs(c, v, dist + 1, u);
    }
}

void solve(int i) {
    input >> n >> d12 >> d23 >> d31;
    string ans, res;
    check >> ans;
    ac >> res;
    if (ans != res) {
        exit(1);
    }
    if (ans == "NO") return;
    for (int i = 1; i <= n; ++ i) {
        adj[i].clear();
    }
    // cout << n << endl;
    for (int i = 1; i < n; ++ i) {
        int u, v;
        ac >> u >> v;
        check >> u >> v;
        // cout << u << " " << v << endl; 
        adj[u].push_back(v);
        adj[v].push_back(u);
    }
    cout << endl;
    dfs(1, 3, 0, -1);
    dfs(3, 2, 0, -1);
    dfs(2, 1, 0, -1);
}

int main() {
    cin.tie(0)->sync_with_stdio(0);
    int tt;
    input >> tt;
    for (int i = 1; i <= tt; ++ i) solve(i);
    return 0;
}
