#include <bits/stdc++.h>
using namespace std;
using ll = long long;
#define print_op(...) ostream& operator<<(ostream& out, const __VA_ARGS__& u)
#define db(val) "["#val" = "<<(val)<<"] "
#define CONCAT_(x, y) x##y
#define CONCAT(x, y) CONCAT_(x, y)
#ifdef LOCAL
#   define clog cerr << setw(__db_level * 2) << setfill(' ') << "" << setw(0)
#   define DB() debug_block CONCAT(dbbl, __LINE__)
    int __db_level = 0;
    struct debug_block {
        debug_block() { clog << "{" << endl; ++__db_level; }
        ~debug_block() { --__db_level; clog << "}" << endl; }
    };
#else
#   define clog if (0) cerr
#   define DB(...)
#endif
template<class U, class V> print_op(pair<U, V>) {
    return out << "(" << u.first << ", " << u.second << ")";
}
template<class Con, class = decltype(begin(declval<Con>()))>
typename enable_if<!is_same<Con, string>::value, ostream&>::type
operator<<(ostream& out, const Con& con) {
    out << "{";
    for (auto beg = con.begin(), it = beg; it != con.end(); ++it)
        out << (it == beg ? "" : ", ") << *it;
    return out << "}";
}
template<size_t i, class T> ostream& print_tuple_utils(ostream& out, const T& tup) {
    if constexpr(i == tuple_size<T>::value) return out << ")";
    else return print_tuple_utils<i + 1, T>(out << (i ? ", " : "(") << get<i>(tup), tup);
}
template<class ...U> print_op(tuple<U...>) {
    return print_tuple_utils<0, tuple<U...>>(out, u);
}
template<typename A, typename B>
bool minimize(A& a, B b) {
    return a > b? a = b, true : false;
}
template<typename A, typename B>
bool maximize(A& a, B b) {
    return a < b? a = b, true : false;
}
const int N = 3e5 + 5;

inline int bit(int x, int i) {
    return x >> i & 1;
}

struct Node {
    int nxt[2];

    Node() {
        memset(nxt, -1, sizeof nxt);
    }
};

struct Trie {
    vector<Node> node;
    vector<int> dp;

    Trie() {
        node = {Node()};
        dp.push_back(-1);
    }

    void insert(int x, int val) {
        int u = 0;
        for (int i = 7; i >= 0; -- i) {
            int curbit = bit(x, i);
            if (node[u].nxt[curbit] == -1) {
                node[u].nxt[curbit] = node.size();
                node.push_back(Node());
                dp.push_back(-1);
            }
            u = node[u].nxt[curbit];
            maximize(dp[u], val);
        }
    }

    int get(int val, int x) {
        int u = 0, ans = -1;
        for (int i = 7; i >= 0; -- i) {
            int curbit_x = bit(x, i);
            int curbit_val = bit(val, i);
            int nodelf = -1, nodert = -1;
            for (int i = 0; i <= 1; ++ i) {
                if ((curbit_x ^ i) == curbit_val) nodelf = i;
                if ((curbit_x ^ i) > curbit_val) nodert = i;
            }
            if (nodert != -1 && node[u].nxt[nodert] != -1) {
                maximize(ans, dp[node[u].nxt[nodert]]);
            }
            if (nodelf != -1 && node[u].nxt[nodelf] != -1) {
                u = node[u].nxt[nodelf];
            } else {
                break;
            }
        }
        return ans;
    }

    int get_max() {
        int ans = 0;
        int u = node[0].nxt[0];
        if (u != -1) maximize(ans, dp[u]);
        u = node[0].nxt[1];
        if (u != -1) maximize(ans, dp[u]);
        return ans;
    }
} trie[300];

int n, a[N];

void solve() {
    cin >> n;
    for (int i = 1; i <= n; ++ i) {
        cin >> a[i];
    }
    for (int i = 0; i <= 200; ++ i) {
        trie[i] = Trie();
    }
    for (int i = 0; i < n; ++ i) {
        int ans = 0;
        for (int j = 0; j <= 200; ++ j) {
            int p = trie[j].get(j ^ i, a[i + 1]);
            // clog << db(i) << db(j) << db(p) << "\n";
            maximize(ans, p);
        }
        trie[a[i + 1]].insert(i, ans + 1);
    }
    int ans = 1;
    for (int i = 0; i <= 200; ++ i) {
        maximize(ans, trie[i].get_max());
    }
    cout << ans << "\n";
}

main() {
    cin.tie(0)->sync_with_stdio(0);
    int tt;
    cin >> tt;
    while (tt --) solve();
}
